taskkill /f /t /im iBridgeCS.exe
taskkill /f /t /im iBridgeHelpCS.exe
C:\windows\System32\regsvr32.exe -s C:\windows\system32\iBridgeCSps.dll
timeout /T 2
C:\windows\System32\regsvr32.exe -s C:\windows\system32\iBridgeHelpCSps.dll
timeout /T 2
C:\windows\SysWow64\regsvr32.exe -s C:\windows\Syswow64\iBridgeCSps.dll
timeout /T 2
C:\windows\SysWow64\regsvr32.exe -s C:\windows\Syswow64\iBridgeHelpCSps.dll
timeout /T 2
"C:\Program Files (x86)\BARROT Corporation\BRLink\iBridgeCS.exe" -service
timeout /T 2
"C:\Program Files (x86)\BARROT Corporation\BRLink\iBridgeHelpCS.exe" -service
timeout /T 2